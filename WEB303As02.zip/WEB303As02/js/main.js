// WEB303 Assignment 2
// Raj M Vekariya


//$(document).ready(function() {
  //$("#content-wrapper a").click(function(event) {
   // event.preventDefault();
    // var contentDiv = $("#content");

    // contentDiv.fadeOut(300, function() {
    //   contentDiv.empty();
    //   var fileToLoad = $(event.target).attr("href", "///Users/rajvekariya/Desktop/WEB303As02/convert.html");
    //   fileToLoad.click (function (event){
    //     event.preventDefault();
    //   });
    //   var xhr = new XMLHttpRequest();
    //   xhr.open("GET", fileToLoad, true);
    //   xhr.onreadystatechange = function() {
    //     if (xhr.readyState === 4 && xhr.status === 200) {
    //       contentDiv.html(xhr.responseText);
    //       contentDiv.fadeIn(300);
    //     }
    //   };
    //   xhr.send();
    // });

//var url = "https://www.youtube.com/";
//$(location).attr('href',url);

 // });
//});





//$(document).ready(function() {
  //const prospect = $('#prospect');
  //const convert = $('#convert');
 // const retain = $('#retain');

 // const content = $('#content');

  //const buttons = [prospect, convert, retain];

//  buttons.forEach(button => {
  //  button.on("click", function(e) {
    //  const fileName = `${e.target.id}.html`;
      //content.slideUp(500, function() {
        //$.ajax({
          //url: fileName,
          //success: function(data) {
           // content.html(data);
            //content.slideDown();
       //   }
      //  });
     // });
    //});
  //});
//});


$(document).ready(function() {
  const prospect = document.querySelector('#prospect');
  const convert = document.querySelector('#convert');
  const retain = document.querySelector('#retain');

  const content = document.querySelector('#content');

  const buttons = [prospect, convert, retain];

  buttons.forEach(button => {
    button.addEventListener("click", function(e) {
      const fileName = `${e.target.id}.html`;
      content.style.display = "none";

      const xhr = new XMLHttpRequest();
      xhr.open("GET", fileName, true);
      xhr.onload = function() {
        if (this.status === 200) {
          content.innerHTML = this.responseText;
          content.style.display = "block";
        } else {
          console.error(`Failed to retrieve ${fileName}`);
        }
      };
      xhr.send();
    });
  });
});
